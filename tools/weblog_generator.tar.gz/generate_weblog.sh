#!/usr/bin/env bash
rm noise_apache.log
python noise_apache.py &
sleep 1
tail -f noise_apache.log | /usr/hdp/current/kafka-broker/bin/kafka-console-producer.sh --topic weblog --broker-list sandbox:6667
